﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class reg_data
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(reg_data))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.new_button = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.save_button = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.clear_button = New System.Windows.Forms.ToolStripButton()
        Me.details_groupbox = New System.Windows.Forms.GroupBox()
        Me.id_text = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.comments_text = New System.Windows.Forms.TextBox()
        Me.email_text = New System.Windows.Forms.TextBox()
        Me.mobile_text = New System.Windows.Forms.TextBox()
        Me.ln_text = New System.Windows.Forms.TextBox()
        Me.fn_text = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ToolStrip1.SuspendLayout()
        Me.details_groupbox.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.new_button, Me.ToolStripSeparator2, Me.save_button, Me.ToolStripSeparator1, Me.clear_button})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(376, 78)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'new_button
        '
        Me.new_button.Image = CType(resources.GetObject("new_button.Image"), System.Drawing.Image)
        Me.new_button.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.new_button.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.new_button.Name = "new_button"
        Me.new_button.Size = New System.Drawing.Size(112, 75)
        Me.new_button.Text = "New Contact"
        Me.new_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 78)
        '
        'save_button
        '
        Me.save_button.Image = CType(resources.GetObject("save_button.Image"), System.Drawing.Image)
        Me.save_button.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.save_button.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.save_button.Name = "save_button"
        Me.save_button.Size = New System.Drawing.Size(112, 75)
        Me.save_button.Text = "Save Contact"
        Me.save_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 78)
        '
        'clear_button
        '
        Me.clear_button.Image = CType(resources.GetObject("clear_button.Image"), System.Drawing.Image)
        Me.clear_button.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.clear_button.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.clear_button.Name = "clear_button"
        Me.clear_button.Size = New System.Drawing.Size(70, 75)
        Me.clear_button.Text = "Clear"
        Me.clear_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'details_groupbox
        '
        Me.details_groupbox.BackColor = System.Drawing.Color.Transparent
        Me.details_groupbox.Controls.Add(Me.id_text)
        Me.details_groupbox.Controls.Add(Me.Label6)
        Me.details_groupbox.Controls.Add(Me.comments_text)
        Me.details_groupbox.Controls.Add(Me.email_text)
        Me.details_groupbox.Controls.Add(Me.mobile_text)
        Me.details_groupbox.Controls.Add(Me.ln_text)
        Me.details_groupbox.Controls.Add(Me.fn_text)
        Me.details_groupbox.Controls.Add(Me.Label5)
        Me.details_groupbox.Controls.Add(Me.Label4)
        Me.details_groupbox.Controls.Add(Me.Label3)
        Me.details_groupbox.Controls.Add(Me.Label2)
        Me.details_groupbox.Controls.Add(Me.Label1)
        Me.details_groupbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.details_groupbox.Location = New System.Drawing.Point(12, 97)
        Me.details_groupbox.Name = "details_groupbox"
        Me.details_groupbox.Size = New System.Drawing.Size(352, 344)
        Me.details_groupbox.TabIndex = 1
        Me.details_groupbox.TabStop = False
        Me.details_groupbox.Text = "Contact Details"
        '
        'id_text
        '
        Me.id_text.Location = New System.Drawing.Point(110, 33)
        Me.id_text.Name = "id_text"
        Me.id_text.Size = New System.Drawing.Size(230, 20)
        Me.id_text.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(69, 31)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 20)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "ID:"
        '
        'comments_text
        '
        Me.comments_text.Location = New System.Drawing.Point(110, 202)
        Me.comments_text.Multiline = True
        Me.comments_text.Name = "comments_text"
        Me.comments_text.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.comments_text.Size = New System.Drawing.Size(230, 129)
        Me.comments_text.TabIndex = 9
        '
        'email_text
        '
        Me.email_text.Location = New System.Drawing.Point(110, 170)
        Me.email_text.Name = "email_text"
        Me.email_text.Size = New System.Drawing.Size(230, 20)
        Me.email_text.TabIndex = 8
        '
        'mobile_text
        '
        Me.mobile_text.Location = New System.Drawing.Point(110, 136)
        Me.mobile_text.Name = "mobile_text"
        Me.mobile_text.Size = New System.Drawing.Size(230, 20)
        Me.mobile_text.TabIndex = 7
        '
        'ln_text
        '
        Me.ln_text.Location = New System.Drawing.Point(110, 102)
        Me.ln_text.Name = "ln_text"
        Me.ln_text.Size = New System.Drawing.Size(230, 20)
        Me.ln_text.TabIndex = 6
        '
        'fn_text
        '
        Me.fn_text.Location = New System.Drawing.Point(110, 67)
        Me.fn_text.Name = "fn_text"
        Me.fn_text.Size = New System.Drawing.Size(230, 20)
        Me.fn_text.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(14, 197)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Comments:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(50, 168)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Email:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(15, 134)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Mobile No.:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Last Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First Name:"
        '
        'reg_data
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(376, 448)
        Me.Controls.Add(Me.details_groupbox)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "reg_data"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add Contact"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.details_groupbox.ResumeLayout(False)
        Me.details_groupbox.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents new_button As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents save_button As ToolStripButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents clear_button As ToolStripButton
    Friend WithEvents details_groupbox As GroupBox

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles clear_button.Click
        '--------Reset all text
        Me.id_text.ResetText()
        Me.fn_text.ResetText()
        Me.ln_text.ResetText()
        Me.mobile_text.ResetText()
        Me.email_text.ResetText()
        Me.comments_text.ResetText()
    End Sub

    Friend WithEvents comments_text As TextBox
    Friend WithEvents email_text As TextBox
    Friend WithEvents mobile_text As TextBox
    Friend WithEvents ln_text As TextBox
    Friend WithEvents fn_text As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label

    Private Sub reg_data_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.save_button.Enabled = False
        Me.clear_button.Enabled = False
        Me.new_button.Enabled = True
        Me.details_groupbox.Enabled = False
    End Sub

    Private Sub new_button_Click(sender As Object, e As EventArgs) Handles new_button.Click
        Me.new_button.Enabled = False
        Me.save_button.Enabled = True
        Me.clear_button.Enabled = True
        Me.details_groupbox.Enabled = True
        '--------Reset all text
        Me.id_text.ResetText()
        Me.fn_text.ResetText()
        Me.ln_text.ResetText()
        Me.mobile_text.ResetText()
        Me.email_text.ResetText()
        Me.comments_text.ResetText()


    End Sub

    Private Sub save_button_Click(sender As Object, e As EventArgs) Handles save_button.Click
        If (Me.id_text.Text = "") Then
            MessageBox.Show("Enter the ID.")
            Exit Sub
        End If
        Me.new_button.Enabled = True
        Me.save_button.Enabled = False
        Me.clear_button.Enabled = False
        Me.details_groupbox.Enabled = False

        '-------------- Write details to .txt files
        Dim path As String
        path = Application.StartupPath + "\Contacts_info\" + Me.id_text.Text

        'Add path to string
        Dim filename As String
        filename = path + "_fn.txt"
        System.IO.File.WriteAllText(filename, Me.fn_text.Text, System.Text.Encoding.UTF8)

        filename = path + "_ln.txt"
        System.IO.File.WriteAllText(filename, Me.ln_text.Text, System.Text.Encoding.UTF8)

        filename = path + "_mn.txt"
        System.IO.File.WriteAllText(filename, Me.mobile_text.Text, System.Text.Encoding.UTF8)

        filename = path + "_email.txt"
        System.IO.File.WriteAllText(filename, Me.email_text.Text, System.Text.Encoding.UTF8)

        filename = path + "_comments.txt"
        System.IO.File.WriteAllText(filename, Me.comments_text.Text, System.Text.Encoding.UTF8)

        MessageBox.Show("Success")

    End Sub

    Friend WithEvents id_text As TextBox
    Friend WithEvents Label6 As Label

    Private Sub reg_data_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If (e.KeyCode = Keys.F6) Then
            new_button_Click(sender, e)
        End If

        If (e.KeyCode = Keys.F7) Then
            save_button_Click(sender, e)
        End If

        If (e.KeyCode = Keys.F8) Then
            ToolStripButton3_Click(sender, e)
        End If
    End Sub
End Class
