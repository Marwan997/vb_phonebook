﻿Public Class search
    Private Sub search_button_Click(sender As Object, e As EventArgs) Handles search_button.Click
        Dim path As String
        path = Application.StartupPath + "\Contacts_info\" + Me.search_id_text.Text

        'Add path to string
        Dim filename As String

        filename = path + "_fn.txt"
        Dim first_name As String
        If (System.IO.File.Exists(filename)) Then
            first_name = System.IO.File.ReadAllText(filename, System.Text.Encoding.UTF8)
            Me.fn_text.Text = first_name
        Else
            Me.fn_text.Text = "Not Found."
        End If

        filename = path + "_ln.txt"
        Dim last_name As String
        If (System.IO.File.Exists(filename)) Then
            last_name = System.IO.File.ReadAllText(filename, System.Text.Encoding.UTF8)
            Me.ln_text.Text = last_name
        Else
            Me.ln_text.Text = "Not Found."
        End If

        filename = path + "_mn.txt"
        Dim mobile_no As String
        If (System.IO.File.Exists(filename)) Then
            mobile_no = System.IO.File.ReadAllText(filename, System.Text.Encoding.UTF8)
            Me.mobile_text.Text = mobile_no
        Else
            Me.mobile_text.Text = "Not Found."
        End If

        filename = path + "_email.txt"
        Dim email As String
        If (System.IO.File.Exists(filename)) Then

            email = System.IO.File.ReadAllText(filename, System.Text.Encoding.UTF8)
            Me.email_text.Text = email
        Else
            Me.email_text.Text = "Not Found."

        End If

        filename = path + "_comments.txt"
        Dim comments As String
        If (System.IO.File.Exists(filename)) Then
            comments = System.IO.File.ReadAllText(filename, System.Text.Encoding.UTF8)
            Me.comments_text.Text = comments
        Else
            Me.comments_text.Text = "Not Found."
        End If
    End Sub
End Class