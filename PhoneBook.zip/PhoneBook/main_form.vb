﻿Public Class main_form
    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        My.Forms.reg_data.MdiParent = Me
        My.Forms.reg_data.Show()
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        My.Forms.reg_data.MdiParent = Me
        My.Forms.search.Show()
    End Sub

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click
        Me.calc_process.StartInfo.FileName = "C:\Windows\System32\calc.exe"
        Me.calc_process.Start()
    End Sub

    Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs) Handles ToolStripButton4.Click
        My.Forms.reg_data.MdiParent = Me
        My.Forms.about.Show()
    End Sub

    Private Sub ToolStripButton5_Click(sender As Object, e As EventArgs) Handles ToolStripButton5.Click
        MessageBox.Show("Goodbye!")
        Application.Exit()
    End Sub

    Private Sub main_form_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown

        If (e.KeyCode = Keys.F1) Then
            ToolStripButton1_Click(sender, e)
        End If

        If (e.KeyCode = Keys.F2) Then
            ToolStripButton2_Click(sender, e)
        End If

        If (e.KeyCode = Keys.F3) Then
            ToolStripButton3_Click(sender, e)
        End If

        If (e.KeyCode = Keys.F4) Then
            ToolStripButton4_Click(sender, e)
        End If

        If (e.KeyCode = Keys.Escape) Then
            ToolStripButton5_Click(sender, e)
        End If

    End Sub
End Class